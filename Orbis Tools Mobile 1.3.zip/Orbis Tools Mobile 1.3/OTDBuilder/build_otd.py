#!/usr/bin/env python3
"""
build_otd.py — PS4 GTA V Texture Dictionary Builder
Wraps ragebuilder.exe with texture_builder.lua via xow64 Wine (Android/Termux)
or native Wine/Windows.

Setup:
    1. Place this script in the same folder as ragebuilder.exe, xg.dll,
       zlib.dll, zlib1.dll, and texture_builder.lua
    2. Put your .dds textures in texture_input/
    3. Run: python3 build_otd.py

Output: texture.otd
"""

import os
import sys
import subprocess
import shutil
import platform
import glob

SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
INPUT_DIR   = os.path.join(SCRIPT_DIR, "texture_input")
OUTPUT_FILE = os.path.join(SCRIPT_DIR, "texture.otd")
RAGEBUILDER = os.path.join(SCRIPT_DIR, "ragebuilder.exe")
LUA_SCRIPT  = os.path.join(SCRIPT_DIR, "texture_builder.lua")
XOW64       = os.path.expanduser("~/xow64")
WINE_C      = os.path.expanduser("~/.xow64_wine/drive_c")

REQUIRED_DLLS = ["xg.dll", "zlib.dll", "zlib1.dll"]


def check_requirements():
    missing = []
    if not os.path.isfile(RAGEBUILDER):
        missing.append("ragebuilder.exe")
    if not os.path.isfile(LUA_SCRIPT):
        missing.append("texture_builder.lua")
    for dll in REQUIRED_DLLS:
        if not os.path.isfile(os.path.join(SCRIPT_DIR, dll)):
            missing.append(dll)
    if not os.path.isdir(INPUT_DIR):
        missing.append("texture_input/ folder")
    if missing:
        print("[!] Missing files:")
        for m in missing:
            print(f"    - {m}")
        sys.exit(1)


def collect_textures():
    textures = []
    for ext in ("*.dds", "*.DDS", "*.png", "*.PNG"):
        textures += glob.glob(os.path.join(INPUT_DIR, ext))
    return textures


def main():
    print("=" * 50)
    print("  PS4 GTA V Texture Dictionary Builder")
    print("=" * 50)

    check_requirements()

    textures = collect_textures()
    if not textures:
        print(f"[!] No textures found in texture_input/")
        print(f"    Add .dds files and try again.")
        sys.exit(1)

    print(f"[*] Found {len(textures)} texture(s)")

    # -----------------------------------------------------------------------
    # xow64 (Android/Termux)
    # -----------------------------------------------------------------------
    if os.path.isfile(XOW64):
        print("[*] Mode: xow64 Wine (Android/Termux)")

        print("[*] Copying files to Wine C drive...")
        shutil.copy2(RAGEBUILDER, WINE_C)
        shutil.copy2(LUA_SCRIPT, WINE_C)
        for dll in REQUIRED_DLLS:
            dll_path = os.path.join(SCRIPT_DIR, dll)
            if os.path.isfile(dll_path):
                shutil.copy2(dll_path, WINE_C)

        # Copy texture_input folder to Wine C drive
        wine_input = os.path.join(WINE_C, "texture_input")
        os.makedirs(wine_input, exist_ok=True)
        for tex in textures:
            shutil.copy2(tex, wine_input)

        print(f"[*] Running ragebuilder...")
        print()
        result = subprocess.run(
            [XOW64, "r", "ragebuilder.exe", "texture_builder.lua"],
            cwd=WINE_C
        )

        # Copy output back
        out_wine = os.path.join(WINE_C, "texture.otd")
        if os.path.isfile(out_wine):
            shutil.copy2(out_wine, OUTPUT_FILE)

        # Cleanup
        for f in ["ragebuilder.exe", "texture_builder.lua", "texture.otd"] + REQUIRED_DLLS:
            try: os.remove(os.path.join(WINE_C, f))
            except: pass
        try: shutil.rmtree(wine_input)
        except: pass

    # -----------------------------------------------------------------------
    # Windows native
    # -----------------------------------------------------------------------
    elif platform.system() == "Windows":
        print("[*] Mode: Windows native")
        print("[*] Running ragebuilder...")
        subprocess.run([RAGEBUILDER, LUA_SCRIPT], cwd=SCRIPT_DIR)

    # -----------------------------------------------------------------------
    # Standard Wine (Linux/macOS)
    # -----------------------------------------------------------------------
    else:
        wine = shutil.which("wine") or shutil.which("wine64")
        if not wine:
            print("[!] Wine not found.")
            print("    Android: install xow64 (~/xow64 install)")
            print("    Linux:   sudo apt install wine")
            sys.exit(1)
        print(f"[*] Mode: Wine ({wine})")
        print("[*] Running ragebuilder...")
        subprocess.run([wine, RAGEBUILDER, LUA_SCRIPT], cwd=SCRIPT_DIR)

    print()
    if os.path.isfile(OUTPUT_FILE):
        size = os.path.getsize(OUTPUT_FILE)
        print(f"[+] Done! texture.otd ({size:,} bytes)")
        print(f"    Saved to: {OUTPUT_FILE}")
    else:
        print("[!] texture.otd was not created.")
        sys.exit(1)


if __name__ == "__main__":
    main()
