#!/usr/bin/env python3
"""
ytd_extractor.py  —  GTA 5 YTD -> DDS extractor
------------------------------------------------
No pip packages required. Python stdlib only.

Usage:
    python ytd_extractor.py <file.ytd> [output_dir]
"""

import sys, struct, zlib, argparse
from pathlib import Path

# ── DDS / D3D constants ───────────────────────────────────────────────────────

RSC7_MAGIC = b"RSC7"
DDS_MAGIC  = b"DDS "

DDPF_FOURCC=0x04; DDPF_RGB=0x40; DDPF_ALPHAPIXELS=0x01
DDSD_CAPS=0x1; DDSD_HEIGHT=0x2; DDSD_WIDTH=0x4; DDSD_PITCH=0x8
DDSD_PIXELFORMAT=0x1000; DDSD_MIPMAPCOUNT=0x20000; DDSD_LINEARSIZE=0x80000
DDSCAPS_COMPLEX=0x8; DDSCAPS_TEXTURE=0x1000; DDSCAPS_MIPMAP=0x400000

# Format FourCCs (stored as u32 little-endian in the struct)
FMT_DXT1=0x31545844; FMT_DXT3=0x33545844; FMT_DXT5=0x35545844
FMT_ATI1=0x31495441; FMT_ATI2=0x32495441; FMT_BC7=0x20374342
# Uncompressed D3DFMT values
FMT_A8R8G8B8=21; FMT_A1R5G5B5=25; FMT_A4R4G4B4=26

# ── Binary helpers ────────────────────────────────────────────────────────────

def u8 (d,o): return struct.unpack_from("<B",d,o)[0]
def u16(d,o): return struct.unpack_from("<H",d,o)[0]
def u32(d,o): return struct.unpack_from("<I",d,o)[0]
def u64(d,o): return struct.unpack_from("<Q",d,o)[0]

def ptr_off(p): return p & 0x0FFFFFFF

def cstring(data, off, maxlen=256):
    end = data.find(b'\x00', off, off+maxlen)
    return (data[off:end] if end!=-1 else data[off:off+maxlen]).decode("latin-1","replace")

# ── RSC7 block-size decoder (exact GTA5/FiveM formula) ───────────────────────

def decode_rsc7_size(flag):
    base = (
          ((flag >> 17) & 0x7f)
        + (((flag >> 11) & 0x3f) << 1)
        + (((flag >>  7) & 0x0f) << 2)
        + (((flag >>  5) & 0x03) << 3)
        + (((flag >>  4) & 0x01) << 4)
    )
    return base * (0x2000 << (flag & 0xF))

# ── RSC7 decompression ────────────────────────────────────────────────────────

def decompress_payload(data):
    if len(data) > 0 and data[0] == 0x78:
        try: return zlib.decompress(data)
        except: pass
    try: return zlib.decompress(data, -15)   # raw deflate
    except: pass
    try: return zlib.decompress(data, 47)    # gzip
    except: pass
    return data

def decompress_rsc7(raw):
    if raw[:4] != RSC7_MAGIC:
        raise ValueError(f"Not an RSC7 file (magic={raw[:4]!r})")

    virt_flags = u32(raw, 8)
    phys_flags = u32(raw, 12)
    virt_size  = decode_rsc7_size(virt_flags)
    phys_size  = decode_rsc7_size(phys_flags)

    print(f"    virt_flags=0x{virt_flags:08X}  declared_virt={virt_size:,}")
    print(f"    phys_flags=0x{phys_flags:08X}  declared_phys={phys_size:,}")

    dec = decompress_payload(raw[16:])
    print(f"    decompressed={len(dec):,}")

    # Virtual block = first virt_size bytes
    virt = dec[:virt_size].ljust(virt_size, b'\x00')

    # Physical block = EVERYTHING after the virtual block.
    # The declared phys_size is a GPU page-aligned size (rounded up),
    # but pixel data pointers use the real unrounded offsets, so we must
    # give the full remaining slice — not just declared_phys bytes.
    phys = dec[virt_size:]

    print(f"    virtual={len(virt):,}B  physical={len(phys):,}B")
    return virt, phys

# ── pgDictionary parser ───────────────────────────────────────────────────────
#
# pgDictionary<grcTexturePC> virtual block layout (64-bit pointers):
#   +0x00  u64  vtable
#   +0x08  u64  block_map
#   +0x10  u64  pad
#   +0x18  u64  pad
#   +0x20  u64  ptr -> hash key array
#   +0x28  u16  hash count
#   +0x2A  u16  hash capacity
#   +0x2C  u32  pad
#   +0x30  u64  ptr -> texture pointer array   <-- tex_arr_ptr
#   +0x38  u16  texture count                  <-- tex_count
#
# grcTexturePC layout (verified from hex dumps):
#   +0x00  u64  vtable
#   +0x08  u64  zeros
#   +0x10  u64  zeros
#   +0x18  u64  zeros
#   +0x20  u64  zeros
#   +0x28  u64  name_ptr   (high nibble 5 = virtual block)
#   +0x30  u64  flags
#   +0x38  u64  zeros
#   +0x40  u64  unk
#   +0x48  u64  zeros
#   +0x50  u16  width
#   +0x52  u16  height
#   +0x54  u8   mip_count
#   +0x55  u8   pad
#   +0x56  u16  stride
#   +0x58  u32  format     (fourcc or D3DFMT)
#   +0x70  u64  pix_ptr    (high nibble 6 = physical block)

def parse_ytd(virt, phys):
    textures = []

    tex_arr_ptr = u64(virt, 0x30)
    tex_count   = u16(virt, 0x38)

    print(f"    tex_arr_ptr=0x{tex_arr_ptr:016X}  tex_count={tex_count}")

    if tex_count == 0 or tex_count > 4096:
        print(f"  [!] tex_count={tex_count} is invalid.")
        return textures

    arr_off = ptr_off(tex_arr_ptr)

    for i in range(tex_count):
        try:
            tex_ptr = u64(virt, arr_off + i*8)
            if tex_ptr == 0: continue
            tb = ptr_off(tex_ptr)

            # Name
            name_ptr = u64(virt, tb + 0x28)
            if name_ptr:
                name = cstring(virt, ptr_off(name_ptr))
            else:
                name = f"tex_{i}"
            name = name.strip('\x00').strip() or f"tex_{i}"
            safe = "".join(c for c in name if c.isalnum() or c in "._-") or f"tex_{i}"

            # Dimensions & format
            width  = u16(virt, tb + 0x50)
            height = u16(virt, tb + 0x52)
            mips   = u8 (virt, tb + 0x54)
            fmt    = u32(virt, tb + 0x58)

            # Pixel data
            pix_ptr = u64(virt, tb + 0x70)
            pix_off = ptr_off(pix_ptr)
            pixels  = extract_pixels(phys, pix_off, width, height, mips, fmt)

            textures.append({
                "name":safe, "width":width, "height":height,
                "mips":max(mips,1), "fmt":fmt, "pixels":pixels
            })

            fmt_name = {FMT_DXT1:"DXT1",FMT_DXT3:"DXT3",FMT_DXT5:"DXT5",
                        FMT_ATI1:"ATI1",FMT_ATI2:"ATI2",FMT_BC7:"BC7 ",
                        FMT_A8R8G8B8:"ARGB"}.get(fmt, f"0x{fmt:08X}")
            print(f"  [{i+1:>3}/{tex_count}] {safe!r:40s}  "
                  f"{width}x{height}  mips={mips}  fmt={fmt_name}  pix={len(pixels):,}B")

        except Exception as e:
            print(f"  [!] Texture #{i} error: {e}")

    return textures

# ── Pixel extraction ──────────────────────────────────────────────────────────

_BLK = {FMT_DXT1:(4,4,8), FMT_ATI1:(4,4,8),
        FMT_DXT3:(4,4,16), FMT_DXT5:(4,4,16),
        FMT_ATI2:(4,4,16), FMT_BC7:(4,4,16)}
_BPP = {FMT_A8R8G8B8:32, FMT_A1R5G5B5:16, FMT_A4R4G4B4:16}

def mip_bytes(w, h, fmt):
    bi = _BLK.get(fmt)
    if bi:
        bw,bh,bpb = bi
        return max(1,(w+bw-1)//bw) * max(1,(h+bh-1)//bh) * bpb
    return max(1,w) * max(1,h) * (_BPP.get(fmt,32)//8)

def extract_pixels(phys, off, w, h, mips, fmt):
    total = 0; cw,ch = w,h
    for _ in range(max(mips,1)):
        total += mip_bytes(cw,ch,fmt); cw=max(1,cw>>1); ch=max(1,ch>>1)
    avail = len(phys) - off
    return phys[off:off+min(total,avail)] if avail>0 else b''

# ── DDS builder ───────────────────────────────────────────────────────────────

def build_dds(tex):
    w,h,mips,fmt,px = tex["width"],tex["height"],tex["mips"],tex["fmt"],tex["pixels"]
    bi = _BLK.get(fmt)
    if bi:
        _,_,bpb = bi
        pitch = max(1,(w+3)//4) * max(1,(h+3)//4) * bpb
        pff=DDPF_FOURCC; fcc=fmt; bits=r=g=b=a=0
        ddsd=DDSD_CAPS|DDSD_HEIGHT|DDSD_WIDTH|DDSD_PIXELFORMAT|DDSD_LINEARSIZE
    else:
        bpp=_BPP.get(fmt,32); pitch=max(1,(w*bpp+7)//8)
        pff=DDPF_RGB|DDPF_ALPHAPIXELS; fcc=0; bits=bpp
        r,g,b,a=(0x00FF0000,0x0000FF00,0x000000FF,0xFF000000) if bpp==32 \
               else (0x7C00,0x03E0,0x001F,0x8000)
        ddsd=DDSD_CAPS|DDSD_HEIGHT|DDSD_WIDTH|DDSD_PIXELFORMAT|DDSD_PITCH
    if mips>1: ddsd|=DDSD_MIPMAPCOUNT
    caps=DDSCAPS_TEXTURE|(DDSCAPS_MIPMAP|DDSCAPS_COMPLEX if mips>1 else 0)
    pf =struct.pack("<IIIIIIII",32,pff,fcc,bits,r,g,b,a)
    hdr=struct.pack("<IIIIIII",124,ddsd,h,w,pitch,1,mips)
    hdr+=b'\x00'*44+pf+struct.pack("<IIII",caps,0,0,0)+b'\x00'*4
    return DDS_MAGIC+hdr+px

# ── Main ──────────────────────────────────────────────────────────────────────

def extract_ytd(ytd_path, output_dir):
    p=Path(ytd_path)
    if not p.exists(): raise FileNotFoundError(f"Not found: {p}")
    out=Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    bar="="*60
    print(f"\n{bar}\n  YTD Extractor — GTA 5\n{bar}")
    print(f"  Input : {p}\n  Output: {out}\n{bar}\n")
    raw=p.read_bytes()
    print("[1] Decompressing RSC7...")
    virt,phys=decompress_rsc7(raw)
    print(f"\n[2] Parsing pgDictionary...")
    textures=parse_ytd(virt,phys)
    if not textures:
        print("\n[!] No textures extracted.")
        print("    Make sure the YTD is unpacked from its RPF first (use OpenIV).")
        raise RuntimeError("No textures extracted")
    print(f"\n[3] Writing {len(textures)} DDS file(s)...\n")
    ok=0
    for tex in textures:
        if not tex["pixels"]: print(f"  [SKIP] {tex['name']!r} — no pixel data"); continue
        name=tex["name"]
        if not name.lower().endswith(".dds"): name+=".dds"
        dest=out/name; dest.write_bytes(build_dds(tex))
        print(f"  [OK]  {name}  ({dest.stat().st_size:,} bytes)")
        ok+=1
    print(f"\n{bar}\n  Done! {ok}/{len(textures)} texture(s) -> {out}\n{bar}\n")

def pause_exit(code=0):
    """On Windows, keep the console open after drag-and-drop."""
    import os
    if os.name == "nt":
        input("\nPress Enter to exit...")
    sys.exit(code)

if __name__=="__main__":
    import os, glob

    # Collect all input paths from argv (drag-and-drop gives them as separate args)
    raw_args = sys.argv[1:]

    # If no args at all, print usage and wait
    if not raw_args:
        print("YTD Extractor — GTA 5")
        print("=" * 60)
        print("Usage:")
        print("  Drag and drop one or more .ytd files (or a folder) onto this script.")
        print("  OR run from command line:")
        print("    python ytd_extractor.py file.ytd [output_dir]")
        print("    python ytd_extractor.py folder/")
        pause_exit(0)

    # Expand all inputs into a flat list of .ytd files
    ytd_files = []
    for arg in raw_args:
        p = Path(arg)
        if p.is_dir():
            # Folder: find all .ytd files recursively
            found = sorted(p.rglob("*.ytd"))
            if not found:
                found = sorted(p.rglob("*.YTD"))
            print(f"[Folder] {p}  —  found {len(found)} .ytd file(s)")
            ytd_files.extend(found)
        elif p.suffix.lower() == ".ytd" and p.is_file():
            ytd_files.append(p)
        else:
            print(f"[SKIP] Not a .ytd file or folder: {arg}")

    if not ytd_files:
        print("[ERROR] No .ytd files found in the provided paths.")
        pause_exit(1)

    # Deduplicate while preserving order
    seen = set()
    unique = []
    for f in ytd_files:
        key = f.resolve()
        if key not in seen:
            seen.add(key)
            unique.append(f)
    ytd_files = unique

    total_files  = len(ytd_files)
    total_ok     = 0
    total_failed = 0

    bar = "=" * 60
    print(f"\n{bar}")
    print(f"  Batch mode: {total_files} file(s) to process")
    print(f"{bar}")

    for idx, ytd in enumerate(ytd_files, 1):
        print(f"\n[{idx}/{total_files}] {ytd.name}")
        # Output folder = same directory as the ytd, named after it
        outd = str(ytd.parent / ytd.stem)
        try:
            extract_ytd(str(ytd), outd)
            total_ok += 1
        except Exception as e:
            total_failed += 1
            print(f"  [FAILED] {ytd.name}: {e}")

    # Final summary
    print(f"\n{bar}")
    print(f"  Batch complete: {total_ok} succeeded, {total_failed} failed")
    print(f"{bar}")

    pause_exit(0 if total_failed == 0 else 1)
