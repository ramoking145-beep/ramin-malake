#!/usr/bin/env python3
"""
build_rpf.py — PS4 GTA V RPF Builder
Wraps ragebuilder.exe via xow64 Wine (Android/Termux) or native Wine/Windows.

Setup:
    1. Place this script in the same folder as ragebuilder.exe and all its DLLs
    2. Put your mod files in archive_input/
    3. Run: python3 build_rpf.py

Output: Archive.rpf
"""

import os
import sys
import subprocess
import shutil
import platform
import glob

SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
INPUT_DIR   = os.path.join(SCRIPT_DIR, "archive_input")
OUTPUT_RPF  = os.path.join(SCRIPT_DIR, "Archive.rpf")
RAGEBUILDER = os.path.join(SCRIPT_DIR, "ragebuilder.exe")
XOW64       = os.path.expanduser("~/xow64")
WINE_C      = os.path.expanduser("~/.xow64_wine/drive_c")


def collect_files():
    if not os.path.isdir(INPUT_DIR):
        print(f"[!] archive_input/ not found in:\n    {SCRIPT_DIR}")
        sys.exit(1)
    entries = []
    for dirpath, dirnames, filenames in os.walk(INPUT_DIR):
        dirnames.sort(key=str.lower)
        for fname in sorted(filenames, key=str.lower):
            disk = os.path.join(dirpath, fname)
            arc  = os.path.relpath(disk, INPUT_DIR).replace(os.sep, "/")
            entries.append((arc, disk))
    return entries


def generate_lua_xow64(entries):
    """Lua for xow64 — files on Wine C drive, Windows paths."""
    lines = [
        "start_uncompressed_pack()",
    ]
    for arc_path, disk_path in entries:
        fname    = os.path.basename(disk_path)
        win_path = f"C:\\\\{fname}"
        lines.append(f"add_to_pack('{win_path}', '{arc_path}', 1)")
    lines += [
        "save_pack('Archive.rpf')",
        "close_pack()",
    ]
    return "\n".join(lines) + "\n"


def generate_lua_native(entries):
    """Lua for Windows/Linux Wine — native paths."""
    lines = ["start_uncompressed_pack()"]
    for arc_path, disk_path in entries:
        disk_esc = disk_path.replace("\\", "\\\\").replace("'", "\\'")
        lines.append(f"add_to_pack('{disk_esc}', '{arc_path}', 1)")
    lines += [
        "save_pack('Archive.rpf')",
        "close_pack()",
    ]
    return "\n".join(lines) + "\n"


def main():
    print("=" * 50)
    print("  PS4 GTA V RPF Builder")
    print("=" * 50)

    if not os.path.isfile(RAGEBUILDER):
        print(f"[!] ragebuilder.exe not found in:\n    {SCRIPT_DIR}")
        sys.exit(1)

    entries = collect_files()
    if not entries:
        print("[!] No files found in archive_input/")
        sys.exit(1)

    dirs = set(os.path.dirname(e[0]) for e in entries if os.path.dirname(e[0]))
    print(f"[*] Found {len(entries)} file(s) in {len(dirs)+1} folder(s)")

    # -----------------------------------------------------------------------
    # xow64 (Android/Termux)
    # -----------------------------------------------------------------------
    if os.path.isfile(XOW64):
        print("[*] Mode: xow64 Wine (Android/Termux)")

        print("[*] Copying files to Wine C drive...")
        shutil.copy2(RAGEBUILDER, WINE_C)
        for dll in glob.glob(os.path.join(SCRIPT_DIR, "*.dll")):
            shutil.copy2(dll, WINE_C)
        for arc_path, disk_path in entries:
            shutil.copy2(disk_path, WINE_C)

        lua      = generate_lua_xow64(entries)
        lua_path = os.path.join(WINE_C, "_build.lua")
        with open(lua_path, "w") as f:
            f.write(lua)

        print(f"[*] Running ragebuilder...")
        print()
        result = subprocess.run(
            [XOW64, "r", "ragebuilder.exe", "_build.lua"],
            cwd=WINE_C
        )

        out_wine = os.path.join(WINE_C, "Archive.rpf")
        if os.path.isfile(out_wine):
            shutil.copy2(out_wine, OUTPUT_RPF)

        for f in ["_build.lua", "ragebuilder.exe", "Archive.rpf"]:
            try: os.remove(os.path.join(WINE_C, f))
            except: pass

    # -----------------------------------------------------------------------
    # Windows native
    # -----------------------------------------------------------------------
    elif platform.system() == "Windows":
        print("[*] Mode: Windows native")
        lua      = generate_lua_native(entries)
        lua_path = os.path.join(SCRIPT_DIR, "_build.lua")
        with open(lua_path, "w") as f:
            f.write(lua)
        print("[*] Running ragebuilder...")
        subprocess.run([RAGEBUILDER, lua_path], cwd=SCRIPT_DIR)
        try: os.remove(lua_path)
        except: pass

    # -----------------------------------------------------------------------
    # Standard Wine (Linux/macOS)
    # -----------------------------------------------------------------------
    else:
        wine = shutil.which("wine") or shutil.which("wine64")
        if not wine:
            print("[!] Wine not found.")
            print("    Android: install xow64 (~/xow64 install)")
            print("    Linux:   sudo apt install wine")
            sys.exit(1)
        print(f"[*] Mode: Wine ({wine})")
        lua      = generate_lua_native(entries)
        lua_path = os.path.join(SCRIPT_DIR, "_build.lua")
        with open(lua_path, "w") as f:
            f.write(lua)
        print("[*] Running ragebuilder...")
        subprocess.run([wine, RAGEBUILDER, lua_path], cwd=SCRIPT_DIR)
        try: os.remove(lua_path)
        except: pass

    print()
    if os.path.isfile(OUTPUT_RPF):
        size = os.path.getsize(OUTPUT_RPF)
        print(f"[+] Done! Archive.rpf ({size:,} bytes)")
        print(f"    Saved to: {OUTPUT_RPF}")
    else:
        print("[!] Archive.rpf was not created.")
        sys.exit(1)


if __name__ == "__main__":
    main()
