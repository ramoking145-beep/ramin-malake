#!/usr/bin/env python3
"""
extract_rpf.py — GTA V RPF7 extractor
Supports PC and PS4 GTA V file formats.

No external dependencies except pycryptodome for AES.

--- Encryption ---

The RPF table of contents is encrypted with the platform AES key.
Individual binary file data may also be AES-encrypted (f2==1 in entry).

PC archives:   TOC key == per-file key == PC_KEY
PS4 archives:  TOC uses PC_KEY (or is unencrypted); per-file data uses PS4_KEY

PS4_KEY source: community-researched key for GTA V PS4 RPF file data.

--- Format classification ---

RSC resource files (header reconstructed, zlib payload preserved):
  On-disk layout inside RPF: version(4) + virt_flags(4) + phys_flags(4) + pad(4) + zlib_payload
  The 16-byte on-disk header is stripped and a proper RSC7 header is prepended on output.
  Known types: .ytd .ydr .ydd .yft .ybn .ynv .ynd .ypt .ysc .ycd .yed .yfd
               .yvr .ywr .yld .ypdb .ybd .ypl .ymap .ymt .ytyp .ymf
  PS4 equivalents: .otd .odr .odd .oft .obn .onv .ond .opt .osc .ocd .oed
                   .ofd .ovr .owr .old .opdb .obd .opl .omap .omt .otyp .omf

Binary/plain files: AES-decrypted then deflate-decompressed as needed.
  .ymf / .omf     — PSO/PSIN manifest (magic: PSIN). NOT RSC7 on PS4; stored
                    as AES+deflate binary. Correctly handled by binary path.
  .gfx / .cfx     — Scaleform SWF variant (magic: GFX/CFX). Never deflated.
  .awc            — Audio Wave Container
  .rel            — Audio relationships/config
  .gxt2           — Text table (magic: GXT2)
  .fxc            — Compiled shader cache (magic: FXC)
  .meta .xml .dat — Plain text/config, may be deflated
"""

import os
import sys
import struct
import zlib
from collections import namedtuple
from pathlib import Path

from Crypto.Cipher import AES


# ─────────────────────────────────────────────
#  CONSTANTS
# ─────────────────────────────────────────────

PC_KEY = bytes([
    0xb3, 0x89, 0x73, 0xaf, 0x8b, 0x9e, 0x26, 0x3a,
    0x8d, 0xf1, 0x70, 0x32, 0x14, 0x42, 0xb3, 0x93,
    0x8b, 0xd3, 0xf2, 0x1f, 0xa4, 0xd0, 0x4d, 0xff,
    0x88, 0x2e, 0x04, 0x66, 0x0f, 0xf9, 0x9d, 0xfd,
])

PS4_KEY = bytes([
    0x59, 0xaa, 0x92, 0xc6, 0x20, 0xca, 0x36, 0x07,
    0x0d, 0xa4, 0xd2, 0x69, 0x06, 0x0b, 0xce, 0x55,
    0x64, 0x73, 0xe7, 0xbf, 0x15, 0x82, 0xb7, 0x17,
    0xa6, 0xbc, 0x37, 0x0f, 0x56, 0x36, 0x64, 0x7d,
])

RPF7_MAGIC   = 0x52504637
RSC7_MAGIC   = b'RSC7'
RSC7_VERSION = 13
ENC_AES      = 0x0FFFFFF9
ENC_OPEN     = 0x4E45504F
SECTOR       = 512
RSC_HDR_SIZE = 16   # version(4) + virt_flags(4) + phys_flags(4) + pad(4)

BINARY_MAGIC_LABELS = [
    (b'PSIN',     'PSO/PSIN manifest'),
    (b'GFX',      'Scaleform GFX'),
    (b'CFX',      'Scaleform CFX'),
    (b'GXT2',     'GXT2 text'),
    (b'FXC\x00',  'FXC shader'),
    (b'\x04\x04', 'AWC audio'),
]

_ExtractJob = namedtuple('_ExtractJob', ['rpf_path', 'out_dir'])


# ─────────────────────────────────────────────
#  SMALL HELPERS
# ─────────────────────────────────────────────

def detect_magic(data: bytes) -> str | None:
    for magic, label in BINARY_MAGIC_LABELS:
        if data[:len(magic)] == magic:
            return label
    return None


def is_rsc7(data: bytes) -> bool:
    return data[:4] == RSC7_MAGIC


def aes_dec(data: bytes, key: bytes) -> bytes:
    """Decrypt complete 16-byte AES-ECB blocks only.
    The last partial block (<16 bytes) is left unencrypted per the RAGE format.
    """
    n_full = (len(data) // 16) * 16
    if n_full == 0:
        return data
    return AES.new(key, AES.MODE_ECB).decrypt(data[:n_full]) + data[n_full:]


def valid_root(d: bytes) -> bool:
    return len(d) >= 16 and struct.unpack_from('<I', d, 4)[0] == 0x7FFFFF00


def get_name(names: bytes, off: int) -> str:
    try:
        end = names.index(b'\x00', off)
        return names[off:end].decode('utf-8', errors='replace')
    except Exception:
        return f'file_{off}'


def try_deflate(data: bytes) -> bytes | None:
    try:
        return zlib.decompress(data, -15)
    except Exception:
        return None


# ─────────────────────────────────────────────
#  RSC FLAG DECODER
# ─────────────────────────────────────────────

def decode_rsc7_size(flag: int) -> int:
    """Decode a RAGE RSC7 virtual/physical size from its packed flag word."""
    base = (
        ((flag >> 17) & 0x7F)
        + (((flag >> 11) & 0x3F) << 1)
        + (((flag >>  7) & 0x0F) << 2)
        + (((flag >>  5) & 0x03) << 3)
        + (((flag >>  4) & 0x01) << 4)
    )
    return base * (0x2000 << (flag & 0xF))


# ─────────────────────────────────────────────
#  RSC ENTRY RECONSTRUCTION
# ─────────────────────────────────────────────

def extract_rsc_entry(raw: bytes, entry: dict) -> bytes:
    """Reconstruct a proper RSC7 file from a raw RPF entry payload.

    On-disk layout inside an RPF sector:
        [0 .. 3]   version      (4 bytes)
        [4 .. 7]   virt_flags   (4 bytes)
        [8 .. 11]  phys_flags   (4 bytes)
        [12 .. 15] padding      (4 bytes)
        [16 ..]    zlib payload (raw deflate stream)

    If the data already has an RSC7 header (re-extracted or passthrough), return as-is.
    For entries whose on-disk size was 0xFFFFFF (unknown), bisect the zlib stream
    to find the exact compressed boundary before returning.
    """
    if raw[:4] == RSC7_MAGIC:
        return raw

    virt_flags = entry['virt_flags']
    phys_flags = entry['phys_flags']

    if entry.get('trim_zlib'):
        try:
            zlib_raw = raw[RSC_HDR_SIZE:]
            expected = decode_rsc7_size(virt_flags) + decode_rsc7_size(phys_flags)
            lo, hi = 0, len(zlib_raw)
            while lo < hi:
                mid = (lo + hi) // 2
                try:
                    dec = zlib.decompress(zlib_raw[:mid], -15)
                    if len(dec) >= expected:
                        hi = mid
                    else:
                        lo = mid + 1
                except zlib.error:
                    lo = mid + 1
            payload = zlib_raw[:lo]
        except Exception:
            payload = raw[RSC_HDR_SIZE:]
    else:
        payload = raw[RSC_HDR_SIZE:]

    rsc7_header = (
        RSC7_MAGIC
        + struct.pack('<I', RSC7_VERSION)
        + struct.pack('<I', virt_flags)
        + struct.pack('<I', phys_flags)
    )
    return rsc7_header + payload


# ─────────────────────────────────────────────
#  RPF7 PARSER
# ─────────────────────────────────────────────

def parse_rpf(data: bytes) -> list[dict]:
    if len(data) < 16:
        raise ValueError('Too small')

    magic, ec, nl, ef = struct.unpack_from('<IIII', data, 0)
    if magic != RPF7_MAGIC:
        raise ValueError(f'Not RPF7 (0x{magic:08x})')

    print(f'    Entries:  {ec}')
    print(f'    NamesLen: {nl}')
    print(f'    EncFlag:  0x{ef:08x}', end=' ')

    eraw = data[16 : 16 + ec * 16]
    nraw = data[16 + ec * 16 : 16 + ec * 16 + nl]

    file_key = None
    if ef == ENC_OPEN:
        print('(unencrypted)')
        de, dn = eraw, nraw
    elif ef == ENC_AES:
        for label, key in [('PC', PC_KEY), ('PS4', PS4_KEY)]:
            d2, n2 = aes_dec(eraw, key), aes_dec(nraw, key)
            if valid_root(d2):
                print(f'(AES — {label} key)')
                de, dn, file_key = d2, n2, key
                break
        else:
            print('(AES — key unknown, raw)')
            de, dn = eraw, nraw
    else:
        for label, key in [('PC', PC_KEY), ('PS4', PS4_KEY)]:
            d2, n2 = aes_dec(eraw, key), aes_dec(nraw, key)
            if valid_root(d2):
                print(f'(unknown flag — {label} key works)')
                de, dn, file_key = d2, n2, key
                break
        else:
            print('(unknown flag — no key matched, raw)')
            de, dn = eraw, nraw

    entries = []
    for i in range(ec):
        d = de[i * 16 : (i + 1) * 16]
        y = struct.unpack_from('<I', d, 0)[0]
        x = struct.unpack_from('<I', d, 4)[0]

        if x == 0x7FFFFF00:
            ei, ec2 = struct.unpack_from('<II', d, 8)
            entries.append({
                'type':          'dir',
                'name':          get_name(dn, y),
                'entries_index': ei,
                'entries_count': ec2,
            })
        elif (x & 0x80000000) == 0:
            noff     = struct.unpack_from('<H', d, 0)[0]
            enc_size = d[2] | (d[3] << 8) | (d[4] << 16)
            sector   = (d[5] | (d[6] << 8) | (d[7] << 16)) & 0x7FFFFF
            f1, f2   = struct.unpack_from('<II', d, 8)
            name     = get_name(dn, noff)
            on_disk  = enc_size if enc_size > 0 else f1
            orig     = f1 if f1 > 0 else on_disk
            entries.append({
                'type':       'file',
                'name':       name,
                'sector':     sector,
                'file_size':  on_disk,
                'orig_size':  orig,
                'is_rsc':     False,
                'virt_flags': 0,
                'phys_flags': 0,
                'data_enc':   (f2 == 1),
                'file_key':   file_key if f2 == 1 else None,
                'compressed': (f1 > 0) and (f1 != on_disk),
                'trim_zlib':  False,
            })
        else:
            noff     = struct.unpack_from('<H', d, 0)[0]
            enc_size = d[2] | (d[3] << 8) | (d[4] << 16)
            sector   = (d[5] | (d[6] << 8) | (d[7] << 16)) & 0x7FFFFF
            f1, f2   = struct.unpack_from('<II', d, 8)
            name     = get_name(dn, noff)
            entries.append({
                'type':       'file',
                'name':       name,
                'sector':     sector,
                'file_size':  enc_size,
                'orig_size':  enc_size,
                'is_rsc':     True,
                'virt_flags': f1,
                'phys_flags': f2,
                'data_enc':   False,
                'file_key':   None,
                'compressed': False,
                'trim_zlib':  False,
            })

    # Fix up RSC entries with unknown size (file_size == 0xFFFFFF).
    # Compute real size from the gap to the next sector boundary.
    rsc_entries   = [e for e in entries if e['type'] == 'file' and e['is_rsc']]
    by_sector     = sorted(rsc_entries, key=lambda e: e['sector'])
    total_sectors = len(data) // SECTOR

    for idx, entry in enumerate(by_sector):
        if entry['file_size'] != 0xFFFFFF:
            continue
        next_sector = (
            by_sector[idx + 1]['sector']
            if idx + 1 < len(by_sector)
            else total_sectors
        )
        entry['file_size'] = (next_sector - entry['sector']) * SECTOR
        entry['trim_zlib'] = True

    return entries


# ─────────────────────────────────────────────
#  PATH BUILDER
# ─────────────────────────────────────────────

def build_paths(entries: list) -> list:
    result = []

    def walk(idx: int, cnt: int, prefix: str) -> None:
        for i in range(idx, min(idx + cnt, len(entries))):
            e = entries[i]
            if e['type'] == 'dir':
                folder = os.path.join(prefix, e['name']) if e['name'] else prefix
                walk(e['entries_index'], e['entries_count'], folder)
            else:
                result.append((os.path.join(prefix, e['name']), e))

    if not entries:
        return result
    root = entries[0]
    if root['type'] == 'dir':
        walk(root['entries_index'], root['entries_count'], '')
    else:
        for e in entries:
            if e['type'] == 'file':
                result.append((e['name'], e))
    return result


# ─────────────────────────────────────────────
#  NESTED RPF SCANNER
# ─────────────────────────────────────────────

def scan_nested_rpfs(folder: str) -> list[str]:
    found = []
    for root, _dirs, files in os.walk(folder):
        for f in files:
            if f.lower().endswith('.rpf'):
                found.append(os.path.join(root, f))
    return sorted(found)


# ─────────────────────────────────────────────
#  CORE EXTRACTOR
# ─────────────────────────────────────────────

def extract(rpf_path: str, out_dir: str) -> None:
    print(f'\n[*] Reading {rpf_path}')
    data = open(rpf_path, 'rb').read()
    print(f'    Size: {len(data):,} bytes')

    entries = parse_rpf(data)
    paths   = build_paths(entries)
    if not paths:
        print('[!] No files found')
        return

    total = len(paths)
    print(f'[*] Extracting {total} file(s) → {out_dir}/')
    os.makedirs(out_dir, exist_ok=True)

    extracted = errors = decomp_ok = key_missing = 0

    for rel_path, e in paths:
        out_path = os.path.join(out_dir, rel_path)
        os.makedirs(os.path.dirname(out_path) or out_dir, exist_ok=True)

        off = e['sector'] * SECTOR
        if off >= len(data):
            print(f'  [!] {rel_path} — sector offset out of bounds')
            errors += 1
            continue

        raw = data[off : off + e['file_size']]
        if len(raw) < e['file_size']:
            print(f'  [!] {rel_path} — truncated ({len(raw)}/{e["file_size"]})')
            errors += 1

        tags = []

        if e['data_enc']:
            if e['file_key'] is not None:
                raw = aes_dec(raw, e['file_key'])
            else:
                tags.append('ENCRYPTED — key unknown, raw bytes written')
                key_missing += 1
                open(out_path, 'wb').write(raw)
                print(f'  {rel_path} ({len(raw):,} bytes) [{", ".join(tags)}]')
                extracted += 1
                continue

        if not e['is_rsc'] and is_rsc7(raw):
            e = dict(e, is_rsc=True, compressed=False, virt_flags=0, phys_flags=0)
            tags.append('RSC7')

        if e['is_rsc']:
            if 'RSC7' not in tags:
                tags.append('RSC')
            final = extract_rsc_entry(raw, e)
        elif e['compressed']:
            dec = try_deflate(raw)
            if dec is not None:
                final = dec
                tags.append('deflate OK')
                decomp_ok += 1
                if e['orig_size'] and len(final) != e['orig_size']:
                    tags.append(f'size mismatch: got {len(final)}, want {e["orig_size"]}')
            else:
                final = raw[:e['orig_size']] if 0 < e['orig_size'] < len(raw) else raw
                tags.append('decomp FAILED — raw fallback')
        else:
            if e['orig_size'] and 0 < e['orig_size'] < len(raw):
                raw = raw[:e['orig_size']]
            final = raw

        if not e['is_rsc'] and final:
            hint = detect_magic(final)
            if hint:
                tags.append(hint)

        open(out_path, 'wb').write(final)
        tag_str = f' [{", ".join(tags)}]' if tags else ''
        print(f'  {rel_path} ({len(final):,} bytes){tag_str}')
        extracted += 1

    print()
    print(f'[+] Done — {extracted}/{total} extracted', end='')
    if decomp_ok:   print(f', {decomp_ok} deflate-decompressed', end='')
    if key_missing: print(f', {key_missing} with unknown key (raw)', end='')
    if errors:      print(f', {errors} error(s)', end='')
    print()


# ─────────────────────────────────────────────
#  NESTED RPF PROMPT + QUEUE
# ─────────────────────────────────────────────

def prompt_nested(nested: list[str], parent_out: str) -> list[_ExtractJob]:
    """Ask the user which nested RPFs to extract and return a job list."""
    print(f'\n  Found {len(nested)} nested RPF(s):')
    for i, n in enumerate(nested, 1):
        rel  = os.path.relpath(n, parent_out)
        size = os.path.getsize(n)
        print(f'  {i:2}. {rel}  ({size:,} bytes)')
    print()

    raw = input('  Extract nested RPFs? Enter number(s), A for all, N to skip [A]: ').strip().lower()

    if raw == 'n':
        print('  Nested RPFs left in place.')
        return []

    if raw in ('', 'a'):
        chosen = nested
    else:
        chosen = []
        for part in raw.replace(',', ' ').split():
            try:
                idx = int(part)
                if 1 <= idx <= len(nested):
                    chosen.append(nested[idx - 1])
                else:
                    print(f'  [SKIP] Invalid number: {part}')
            except ValueError:
                print(f'  [SKIP] Not a number: {part}')

    jobs = []
    for path in chosen:
        out = os.path.join(os.path.dirname(path), Path(path).stem)
        jobs.append(_ExtractJob(path, out))
    return jobs


# ─────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: python3 extract_rpf.py <input.rpf> [output_folder]')
        sys.exit(1)

    rpf = sys.argv[1]
    if not os.path.isfile(rpf):
        print(f'[!] Not found: {rpf}')
        sys.exit(1)

    default_out = os.path.join(
        os.path.dirname(rpf) or '.',
        Path(rpf).stem + '_extracted',
    )
    out = sys.argv[2] if len(sys.argv) >= 3 else default_out

    queue: list[_ExtractJob] = [_ExtractJob(rpf, out)]
    ok = fail = 0

    while queue:
        job = queue.pop(0)
        try:
            extract(job.rpf_path, job.out_dir)
            ok += 1
        except Exception as e:
            print(f'[ERROR] {e}')
            fail += 1
            continue

        nested = scan_nested_rpfs(job.out_dir)
        if nested:
            more = prompt_nested(nested, job.out_dir)
            queue.extend(more)

    print(f'\n[=] Total: {ok} RPF(s) extracted, {fail} failed')
