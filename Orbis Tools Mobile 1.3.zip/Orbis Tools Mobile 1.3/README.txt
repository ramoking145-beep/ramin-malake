     +===========================================+
| ██████╗ ██████╗ ██████╗ ██╗███████╗       |
|██╔═══██╗██╔══██╗██╔══██╗██║██╔════╝       |
|██║   ██║██████╔╝██████╔╝██║███████╗       |
|██║   ██║██╔══██╗██╔══██╗██║╚════██║       |
|╚██████╔╝██║  ██║██████╔╝██║███████║       |
| ╚═════╝ ╚═╝  ╚═╝╚═════╝ ╚═╝╚══════╝       |
|                                           |
|████████╗ ██████╗  ██████╗ ██╗     ███████╗|
|╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝|
|   ██║   ██║   ██║██║   ██║██║     ███████╗|
|   ██║   ██║   ██║██║   ██║██║     ╚════██║|
|   ██║   ╚██████╔╝╚██████╔╝███████╗███████║|
|   ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝|
+===========================================+




    MAKE SURE YOU HAVE INSTALLED THE DEPENDENCIES 
    I ASKED YOU TO INSTALL, IF NOT READ WHAT I SAID IN
    THE DISCORD SERVER>THREADS>MOBILE FILES.
    AND MAKE SURE YOU HAVE FILES ACCESS FOR TERMUX
    ALLOWED.

   NOW JUST PUT THE FILES IN YOUR DEVICE MEMORY
   NOT IN THE DOWNLOADS FOLDER, BUT BEFORE THE
   THE DOWNLOADS FOLDER.

   DOWNLOAD THE ORBIS RPF BUILDER AND ORBIS TEX
   TURE BUILDER FROM THE DISCORD SERVER. EXTRACT
   THE ORBIS RPF FOLDER FILES INSIDE "RPFBuilder", AN
   D DO THE SAME FOR THE ORBIS TEXTURE BUILDER, EX
   TRACT THE FILES INSIDE "OTDBuilder".

 FOR THE RPF BUILDER, PUT YOUR FILES INSIDE THE FOLDER
 CALLED "archive_input" THEN IN TERMUX RUN THESE COM
 MANDS:



   "cd /sdcard/RPFBuilder"
   "python build_rpf.py"

                                            

 AND IT SHOULD BUILD IT INTO AN RPF.

 FOR THE TEXTURE BUILDER, PUT YOUR FILES INSIDE THE
 FOLDER CALLED "texture_input" THEN IN TERMUX RUN 
 THESE COMMANDS:

  "cd /sdcard/OTDBuilder"
  "python build_otd.py"

  AND IT SHOULD BUILD INTO A .OTD

   TO EXTRACT DDS FILES FROM A .YTD FILE, PUT YOUR
   YTD FILE INSIDE THE FOLDER (OTDBuilder)

   THEN RUN THESE COMMANDS:

  "python extract_ytd.py NameOfYourYTD.ytd

  AND IT SHOULD EXTRACT A FOLDER WITH THE SAME
  NAME OF THE YTD, WHICH CONTAINS THE DDS FILES.






=====================================
        HOW DOES IT WORK??????
=====================================

 --------- EMULATION WITH THE MOST MINIMAL 
   DEPENDENCIES IN A TERMINAL ---------------------



